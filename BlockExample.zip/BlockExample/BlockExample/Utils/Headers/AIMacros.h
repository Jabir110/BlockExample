//
//  AIMacros.h
//  BlockExample
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#ifndef AIMacros_h
#define AIMacros_h

#pragma mark - APP DELEGATE
#pragma mark -
////////////////////////////////////////////////////////////////////////
///////////////////////////// APP DELEGATE /////////////////////////////
////////////////////////////////////////////////////////////////////////
#define appDelegate                                                            \
((AppDelegate *)[[UIApplication sharedApplication] delegate])

#pragma mark - DEVICE TYPE MACROS
#pragma mark -
////////////////////////////////////////////////////////////////////////
////////////////////////// DEVICE TYPE MACROS //////////////////////////
////////////////////////////////////////////////////////////////////////
#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define IS_RETINA ([[UIScreen mainScreen] scale] >= 2.0)

#pragma mark - DEVICE DIMENSION MACROS
#pragma mark -
////////////////////////////////////////////////////////////////////////
/////////////////////// DEVICE DIMENSION MACROS ////////////////////////
////////////////////////////////////////////////////////////////////////
#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define SCREEN_MAX_LENGTH (MAX(SCREEN_WIDTH, SCREEN_HEIGHT))
#define SCREEN_MIN_LENGTH (MIN(SCREEN_WIDTH, SCREEN_HEIGHT))

#define IS_IPHONE_4_OR_LESS (IS_IPHONE && SCREEN_MAX_LENGTH < 568.0)
#define IS_IPHONE_5 (IS_IPHONE && SCREEN_MAX_LENGTH == 568.0)
#define IS_IPHONE_6 (IS_IPHONE && SCREEN_MAX_LENGTH == 667.0)
#define IS_IPHONE_6P (IS_IPHONE && SCREEN_MAX_LENGTH == 736.0)

#pragma mark - UTILITY MACROS
#pragma mark -
////////////////////////////////////////////////////////////////////////
//////////////////////////// UTILITY MACROS ////////////////////////////
////////////////////////////////////////////////////////////////////////
#define SERVICE_MANAGER [AIServiceManager sharedManager]
#define APP_NAME @"BlockExample"

#pragma mark - FONT MACROS
#pragma mark -
////////////////////////////////////////////////////////////////////////
////////////////////////////// FONT MACROS /////////////////////////////
////////////////////////////////////////////////////////////////////////
#define FONT_FAMILY_REGULAR @"CenturyGothic"
#define FONT_FAMILY_BOLD @"CenturyGothic-Bold"
#define FONT_FAMILY_SEMIBOLD @""

#define REGULAR_FONT(s)                                                        \
[UIFont fontWithName:FONT_FAMILY_REGULAR size:PROPORTIONAL_FONT_SIZE(s)]
#define BOLD_FONT(s)                                                           \
[UIFont fontWithName:FONT_FAMILY_BOLD size:PROPORTIONAL_FONT_SIZE(s)]
#define SEMI_BOLD_FONT(s)                                                      \
[UIFont fontWithName:FONT_FAMILY_SEMIBOLD size:PROPORTIONAL_FONT_SIZE(s)]

#define PROPORTIONAL_FONT_SIZE(s)                                              \
(s + (IS_IPHONE_4_OR_LESS ? -3 : 0) + (IS_IPHONE_5 ? -2 : 0) +                \
(IS_IPHONE_6 ? -1 : 0) + (IS_IPHONE_6P ? 0 : 0))

#pragma mark - COLOR MACROS
#pragma mark -
////////////////////////////////////////////////////////////////////////
///////////////////////////// COLOR MACROS /////////////////////////////
////////////////////////////////////////////////////////////////////////
#define COLOR(r, g, b)                                                         \
[UIColor colorWithRed:(r / 255.0f)                                           \
green:(g / 255.0f)                                           \
blue:(b / 255.0f)                                           \
alpha:1.0]
#define COLOR_WITH_ALPHA(r, g, b, a)                                           \
[UIColor colorWithRed:(r / 255.0f)                                           \
green:(g / 255.0f)                                           \
blue:(b / 255.0f)                                           \
alpha:a / 1.0f];

#define PIXEL_COLOR                                                            \
[UIColor colorWithPatternImage:[UIImage imageNamed:@"bgPixel"]]
#define PIXEL_IMAGE [UIImage imageNamed:@"bgPixel"]

#define NAV_BAR_COLOR COLOR(48,52,63)
#define THEME_PINK_COLOR COLOR(252,0,82)
#define TEXT_FIELD_PLACEHOLDER_COLOR COLOR(136,136,136)
#define TEXT_FIELD_TEXT_COLOR COLOR(51,51,51)
#define SEPARATOR_COLOR COLOR(213,213,213)
#define BUTTON_BORDER_COLOR SEPARATOR_COLOR
#define BUTTON_BACKGROUND_COLOR COLOR(244,244,244)
#define BUTTON_TITLE_COLOR COLOR(119,119,119)
#define SEGMENT_CONTROL_BACKGROUND_COLOR COLOR(247,247,247)
#define SEGMENT_CONTROL_SELECTED_BACKGROUND_COLOR COLOR(221,221,221)

#pragma mark - ALERT MACROS
#pragma mark -
////////////////////////////////////////////////////////////////////////
////////////////////////////// ALERT MACROS /////////////////////////////
////////////////////////////////////////////////////////////////////////
#define cancelButtonIndex 1000


#endif /* AIMacros_h */
