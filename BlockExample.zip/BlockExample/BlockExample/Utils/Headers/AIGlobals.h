//
//  AIGlobals.h
//  BlockExample
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#ifndef AIGlobals_h
#define AIGlobals_h

 #pragma mark -
////////////////////////////////////////
// ********** APP DELEGATE ********** //
////////////////////////////////////////
#import "AppDelegate.h"

#pragma mark - HEADERS
#pragma mark -
////////////////////////////////////////
// ******** GLOBAL HEADERS ********** //
////////////////////////////////////////
#import "AIMacros.h"
#import "AIServiceConstants.h"


#pragma mark - PODS
#pragma mark -
////////////////////////////////////////
// ************* PODS *************** //
////////////////////////////////////////
#import <AFNetworking/AFNetworking.h>
#import <SVProgressHUD/SVProgressHUD.h>

#pragma mark - UTILS
#pragma mark -
////////////////////////////////////////
// ************ UTILS *************** //
////////////////////////////////////////
#import "AIServiceManager.h"
#import "AIAlertUtils.h"
#import "AIHudUtils.h"

#pragma mark - CATEGORIES
#pragma mark -
////////////////////////////////////////
// ********** CATEGORIES ************ //
////////////////////////////////////////
#import "NSString+AIString.h"


#endif /* AIGlobals_h */
