//
//  AIHudUtils.h
//  CustomControls
//
//  Created by agile on 10/02/16.
//  Copyright © 2016 agile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AIHudUtils : NSObject

#pragma mark - SETUP HUD
#pragma mark -
+ (void)configureHud;

#pragma mark - DISPLAY HUD
#pragma mark -
+ (void)showHUD;
+ (void)showHUDWithMessage:(NSString *)message;

#pragma mark - HIDE HUD
#pragma mark -
+ (void)hideHUD;

@end
