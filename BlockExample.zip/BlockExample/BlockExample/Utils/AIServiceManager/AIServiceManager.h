//
//  AIServiceManager.h
//  BlockExample
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AIServiceManager : NSObject

@property(nonatomic, strong) AFHTTPSessionManager *manager;

#pragma mark - WEB SERVICE CLIENT
#pragma mark -
- (AFHTTPSessionManager *)webServiceClient;

#pragma mark - SINGLETON INSTANCE
#pragma mark -
+ (AIServiceManager *)sharedManager;

#pragma mark - ENTRY OPTIONS
#pragma mark -

-(void)getCategoryListWithCompletionHandler:(void (^)(BOOL isSuccess, NSDictionary *dictResponse))completionHandler;

-(void)getCityList:(void(^)(BOOL isSuccess, NSDictionary *dictResponse))completionHandler;


-(void)postLoginWithEmail:(NSString *)email password:(NSString *)password completionHandler:(void(^) (BOOL isSuccess,NSDictionary *dictResponse))completionHandler;

@end
