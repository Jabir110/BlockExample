//
//  AIAlertUtils.h
//  CustomControls
//
//  Created by agile on 10/02/16.
//  Copyright © 2016 agile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AIAlertUtils : NSObject

#pragma mark - ALERT VIEW
#pragma mark -
+ (void)displayAlertFromController:(UIViewController *)viewController
                         withTitle:(NSString *)title
                           message:(NSString *)message
                 otherButtonTitles:(NSArray *)otherTitles
                        isOkButton:(BOOL)isOkayButton
               preferredAlertStyle:(UIAlertControllerStyle)style
                    withCompletion:(void (^)(NSInteger))completionHandler;

+ (void)displayAlertWithTitle:(NSString *)title
                      message:(NSString *)message
            otherButtonTitles:(NSArray *)otherTitles
          preferredAlertStyle:(UIAlertControllerStyle)style
               withCompletion:(void (^)(NSInteger index))completionHandler;

+ (void)displayAlertWithMessage:(NSString *)message
              otherButtonTitles:(NSArray *)otherTitles
            preferredAlertStyle:(UIAlertControllerStyle)style
                 withCompletion:(void (^)(NSInteger index))completionHandler;

+ (void)displayAlertWithCancelMessage:(NSString *)message
                    otherButtonTitles:(NSArray *)otherTitles
                  preferredAlertStyle:(UIAlertControllerStyle)style
                       withCompletion:
                           (void (^)(NSInteger index))completionHandler;


+ (void)noInternet;

+ (void)notImplemented;

//+(void)shakeTextResponder:(id)responder;

@end
