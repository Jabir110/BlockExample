//
//  AIAlertUtils.m
//  CustomControls
//
//  Created by agile on 10/02/16.
//  Copyright © 2016 agile. All rights reserved.
//

#define NO_INTERNET                                                            \
  @"Internet connection not available. \n Please check your connection and "   \
  @"try again."

#define NOT_IMPLEMENTED @"Feature not implemented. Please refer to release notes and / or concern the development team. Thanks!"

#import "AIAlertUtils.h"

@implementation AIAlertUtils

#pragma mark - ALERT VIEW
#pragma mark -
+ (void)displayAlertFromController:(UIViewController *)viewController
                         withTitle:(NSString *)title
                           message:(NSString *)message
                 otherButtonTitles:(NSArray *)otherTitles
                        isOkButton:(BOOL)isOkayButton
               preferredAlertStyle:(UIAlertControllerStyle)style
                    withCompletion:(void (^)(NSInteger))completionHandler {

//  if (message.length == 0)
//    return;

  UIAlertController *alertController =
      [UIAlertController alertControllerWithTitle:title
                                          message:message
                                   preferredStyle:style];
    
    if(title.length>0){
        NSMutableAttributedString *hogan = [[NSMutableAttributedString alloc] initWithString:title];
        NSLog(@"hogan: %@",hogan);
        NSLog(@"title: %@",title);        
//        [hogan addAttribute:NSFontAttributeName
//                      value:REGULAR_FONT(16.0)
//                      range:NSMakeRange(0, [title length])];
//        NSLog(@"hogan: %@",hogan);
//        [hogan addAttribute:NSForegroundColorAttributeName
//                      value:THEME_PINK_COLOR
//                      range:NSMakeRange(0, [title length])];
//        NSLog(@"hogan: %@",hogan);
        [alertController setValue:hogan forKey:@"attributedTitle"];
    }

    if(message.length>0){
        NSMutableAttributedString *messageAtt = [[NSMutableAttributedString alloc] initWithString:message];
//        [messageAtt addAttribute:NSFontAttributeName
//                           value:REGULAR_FONT(14.0)
//                           range:NSMakeRange(0, [message length])];
//        [messageAtt addAttribute:NSForegroundColorAttributeName
//                           value:TEXT_FIELD_TEXT_COLOR
//                           range:NSMakeRange(0, [message length])];
        [alertController setValue:messageAtt forKey:@"attributedMessage"];
    }
    


    if(style==UIAlertControllerStyleAlert){
        UIAlertAction *okayAction =
        [UIAlertAction actionWithTitle:isOkayButton ? @"Okay" : @"Cancel"
                                 style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *_Nonnull action) {
                                   if (completionHandler) {
                                       completionHandler(cancelButtonIndex);
                                   }
                               }];
        [alertController addAction:okayAction];
    }
    
  

  for (int i = 0; i < otherTitles.count; i++) {
      

      
    UIAlertAction *actionToBeAdded =
        [UIAlertAction actionWithTitle:otherTitles[i]
                                 style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *_Nonnull action) {
                                 if (completionHandler) {
                                   completionHandler(i);
                                 }
                               }];
    [alertController addAction:actionToBeAdded];
  }

    if(style==UIAlertControllerStyleActionSheet){
        UIAlertAction *okayAction =
        [UIAlertAction actionWithTitle:isOkayButton ? @"Okay" : @"Cancel"
                                 style:UIAlertActionStyleDefault
                               handler:nil];
        [alertController addAction:okayAction];
    }

  dispatch_async(dispatch_get_main_queue(), ^{
    [viewController presentViewController:alertController
                                 animated:YES
                               completion:^{
                               }];
      [alertController.view setTintColor:TEXT_FIELD_TEXT_COLOR];
  });
}

+ (void)displayAlertWithTitle:(NSString *)title
                      message:(NSString *)message
            otherButtonTitles:(NSArray *)otherTitles
          preferredAlertStyle:(UIAlertControllerStyle)style
               withCompletion:(void (^)(NSInteger index))completionHandler {
  [self displayAlertFromController:[self topViewController:[self topViewController]]
                         withTitle:title
                           message:message
                 otherButtonTitles:otherTitles
                        isOkButton:YES
               preferredAlertStyle:style
                    withCompletion:completionHandler];
}

+ (void)displayAlertWithMessage:(NSString *)message
              otherButtonTitles:(NSArray *)otherTitles
            preferredAlertStyle:(UIAlertControllerStyle)style
                 withCompletion:(void (^)(NSInteger))completionHandler {
  [self displayAlertWithTitle:APP_NAME
                      message:message
            otherButtonTitles:otherTitles
          preferredAlertStyle:style
               withCompletion:completionHandler];
}

+ (void)displayAlertWithCancelMessage:(NSString *)message
                    otherButtonTitles:(NSArray *)otherTitles
                  preferredAlertStyle:(UIAlertControllerStyle)style
                       withCompletion:(void (^)(NSInteger))completionHandler {
    
    [self displayAlertFromController:[self topViewController:[self topViewController]]
                         withTitle:APP_NAME
                           message:message
                 otherButtonTitles:otherTitles
                        isOkButton:NO
               preferredAlertStyle:style
                    withCompletion:completionHandler];
}


+ (void)noInternet {

  [self displayAlertWithCancelMessage:NO_INTERNET
                    otherButtonTitles:@[ @"Settings" ]
                  preferredAlertStyle:UIAlertControllerStyleAlert
                       withCompletion:^(NSInteger index) {
                         if (index == 0) {
                           [[UIApplication sharedApplication]
                               openURL:
                                   [NSURL
                                       URLWithString:
                                           UIApplicationOpenSettingsURLString]];
                         }
                       }];
}

+(void)notImplemented{
    
    [self displayAlertFromController:[self topViewController:[self topViewController]]
                           withTitle:APP_NAME
                             message:NOT_IMPLEMENTED
                   otherButtonTitles:nil
                          isOkButton:YES
                 preferredAlertStyle:UIAlertControllerStyleAlert
                      withCompletion:nil];

}

+ (UIViewController *)topViewController{
    return [self topViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
}

+ (UIViewController *)topViewController:(UIViewController *)rootViewController
{
    if (rootViewController.presentedViewController == nil) {
        if ([rootViewController isKindOfClass:[UINavigationController class]]) {
            UINavigationController *navigationController = (UINavigationController *)rootViewController;
            UIViewController *lastViewController = [[navigationController viewControllers] lastObject];
            return lastViewController;
            
        }
        return rootViewController;
    }
    
    
    if ([rootViewController.presentedViewController isKindOfClass:[UINavigationController class]]) {
        UINavigationController *navigationController = (UINavigationController *)rootViewController.presentedViewController;
        UIViewController *lastViewController = [[navigationController viewControllers] lastObject];
        return [self topViewController:lastViewController];
    }
    
    UIViewController *presentedViewController = (UIViewController *)rootViewController.presentedViewController;
    return [self topViewController:presentedViewController];
}


+ (void)alertTextFieldDidChange:(UITextField *)sender
{
    UIAlertController *alertController = (UIAlertController *)[AIAlertUtils topViewController:[AIAlertUtils topViewController]];
    if (alertController)
    {
        
        NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}" ;
        
      
        NSPredicate *emailTest = [NSPredicate predicateWithFormat:
                                  @"SELF MATCHES %@", stricterFilterString];
        
 
        BOOL boolToReturn = [emailTest evaluateWithObject:sender.text];
        


        UIAlertAction *okAction = alertController.actions.lastObject;
        okAction.enabled = boolToReturn;
    }
}

@end
