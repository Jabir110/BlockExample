//
//  ViewController.m
//  BlockExample
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

//    [SERVICE_MANAGER getCategoryListWithCompletionHandler:^(BOOL isSuccess, NSDictionary *dictResponse) {
//    
//        if (isSuccess){
//            NSLog(@"Success");
//            NSLog(@"dictResponse: %@",dictResponse);
//        }else{
//            NSLog(@"Fail");
//        }
//    }];
    
    [SERVICE_MANAGER getCityList:^(BOOL isSuccess, NSDictionary *dictResponse) {
       
        if (isSuccess){
            NSLog(@"Success");
            NSLog(@"dictResponse: %@",dictResponse);
        }else{
            NSLog(@"Fail");
        }
        
    }];
    
    
//    [SERVICE_MANAGER postLoginWithEmail:@"jabir@virtualheight.com" password:@"123456" completionHandler:^(BOOL isSuccess, NSDictionary *dictResponse) {
//       
//        if (isSuccess) {
//            
//            NSLog(@"dictResponse: %@",dictResponse);
//        }else{
//            NSLog(@"Fail");
//        }
//    }];
    
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)ActionBTN:(id)sender
{
    NSString *strEmail = txtFname.text.whiteSpaceTrimmedString;
    NSString *strPassword = txtLname.text.whiteSpaceTrimmedString;
    
    if (strEmail.length == 0)
    {
        NSLog(@"Fname Error");
    }
    else if (strPassword.length == 0)
    {
        NSLog(@"Lname Error");
        NSLog(@"strEmail:%@",strEmail);
    }
    else
    {
        NSLog(@"strEmail:%@",strEmail);
        NSLog(@"strPassword:%@",strPassword);
        NSLog(@"Success");
    }
}
@end





