//
//  NSString+AIString.m
//  BlockExample
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import "NSString+AIString.h"

@implementation NSString (AIString)

- (NSString *)whiteSpaceTrimmedString {
    return [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

@end
