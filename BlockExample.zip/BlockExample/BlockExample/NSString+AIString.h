//
//  NSString+AIString.h
//  BlockExample
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (AIString)

- (NSString *)whiteSpaceTrimmedString;

@end
